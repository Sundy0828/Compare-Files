package com.codebehind;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Arrays;
import java.util.Comparator;
import java.awt.List;

public class App {
    private JButton button1;
    private JPanel panel1;
    private JButton browseForFileButton;
    private JLabel noFolderSelectedLabel;
    private JLabel fileLocationLabel;
    private JButton browseForComareFileButton;
    private JLabel noFileSelectedLbl;
    private JScrollPane scrollPane1;
    private JTextArea textArea2;
    private JComboBox compareBy;
    private JComboBox orderBy;
    private JLabel listLbl;

    // sourcePath is normal file and save path is the save of the original
    String FolderPath = "";
    String FilePath = "";
    String Alist = "AFTER\n";
    String Blist = "\n\nBEFORE\n";
    String list = "";
    Boolean compareDatePassed = Boolean.FALSE;

    public App() {

        compareBy.addItem("Select compare by:");
        compareBy.addItem("Created Date");
        compareBy.addItem("Last modified");
        compareBy.addItem("Last access");

        orderBy.addItem("Select order by:");
        orderBy.addItem("More recent");
        orderBy.addItem("Less recent");


        //when compare file button is clicked
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //if if file path is not nothing
                if (FolderPath != "" && FilePath != "") {

                    try {
                        File dir = new File(FolderPath);

                        Collection<String> files  =new ArrayList<String>();

                        if(dir.isDirectory()){
                            File[] listFiles = dir.listFiles();

                            Arrays.sort(listFiles, new Comparator<File>(){
                                public int compare(File f1, File f2)
                                {
                                    try {
                                        Path p = Paths.get(f1.getAbsolutePath());
                                        BasicFileAttributes view = Files.getFileAttributeView(p, BasicFileAttributeView.class)
                                                .readAttributes();
                                        Path pTwo = Paths.get(f2.getAbsolutePath());
                                        BasicFileAttributes viewTwo = Files.getFileAttributeView(pTwo, BasicFileAttributeView.class)
                                                .readAttributes();
                                        if (String.valueOf(compareBy.getSelectedItem()) == "Created Date") {
                                            return Integer.valueOf(view.creationTime().compareTo(viewTwo.creationTime()));
                                        }else if (String.valueOf(compareBy.getSelectedItem()) == "Last access") {
                                            return Integer.valueOf(view.lastAccessTime().compareTo(viewTwo.lastAccessTime()));
                                        }
                                    } catch (IOException ex) {
                                        // LOG or output exception
                                        ex.printStackTrace();
                                    }

                                    return Long.valueOf(f1.lastModified()).compareTo(f2.lastModified());

                                } });
                            if (String.valueOf(orderBy.getSelectedItem()) == "More recent") {
                                for (int i = listFiles.length - 1; i >= 0; i--) {
                                    if (listFiles[i].isFile()) {
                                        files.add(listFiles[i].getName());
                                    }
                                }
                            }else {
                                for (File file:listFiles) {
                                    if (file.isFile()) {
                                        files.add(file.getName());
                                    }
                                }
                            }


                            for (String shortPath: files) {
                                Path p = Paths.get(FolderPath + "/" + shortPath);
                                BasicFileAttributes view
                                        = Files.getFileAttributeView(p, BasicFileAttributeView.class)
                                        .readAttributes();
                                Path pTwo = Paths.get(FilePath);
                                BasicFileAttributes viewTwo
                                        = Files.getFileAttributeView(pTwo, BasicFileAttributeView.class)
                                        .readAttributes();
                                if (String.valueOf(compareBy.getSelectedItem()) == "Created Date") {
                                    if (view.creationTime().toMillis() < viewTwo.creationTime().toMillis()) {
                                        Blist = Blist + "Creation Time: " + view.creationTime() + ", Last Modified Time: " + view.lastModifiedTime() + ", Last Access Time: " + view.lastAccessTime() + " - " + shortPath + "\n";
                                        compareDatePassed = true;
                                    }else {
                                        Alist = Alist + "Creation Time: " + view.creationTime() + ", Last Modified Time: " + view.lastModifiedTime() + ", Last Access Time: " + view.lastAccessTime() + " - " + shortPath + "\n";
                                    }
                                }else if (String.valueOf(compareBy.getSelectedItem()) == "Last access") {
                                    if (view.lastAccessTime().toMillis() < viewTwo.lastAccessTime().toMillis()) {
                                        Blist = Blist + "Creation Time: " + view.creationTime() + ", Last Modified Time: " + view.lastModifiedTime() + ", Last Access Time: " + view.lastAccessTime() + " - " + shortPath + "\n";
                                        compareDatePassed = true;
                                    }else {
                                        Alist = Alist + "Creation Time: " + view.creationTime() + ", Last Modified Time: " + view.lastModifiedTime() + ", Last Access Time: " + view.lastAccessTime() + " - " + shortPath + "\n";
                                    }
                                }else {
                                    if (view.lastModifiedTime().toMillis() < viewTwo.lastModifiedTime().toMillis()) {
                                        Blist = Blist + "Creation Time: " + view.creationTime() + ", Last Modified Time: " + view.lastModifiedTime() + ", Last Access Time: " + view.lastAccessTime() + " - " + shortPath + "\n";
                                        compareDatePassed = true;
                                    }else {
                                        Alist = Alist + "Creation Time: " + view.creationTime() + ", Last Modified Time: " + view.lastModifiedTime() + ", Last Access Time: " + view.lastAccessTime() + " - " + shortPath + "\n";
                                    }
                                }

                                System.out.println("Creation Time: "+view.creationTime()+", Last Modified Time: "+view.lastModifiedTime()+", Last Access Time: "+view.lastAccessTime() + " - " + shortPath);
                                //getAttributes(FolderPath + "/" + shortPath, shortPath);
                            }
                            if (Alist != "AFTER\n" && Blist != "\n\nBEFORE\n") {
                                list = Alist + Blist;
                            }else if (Alist != "AFTER\n") {
                                list = Alist;
                            }else if (Blist != "\n\nBEFORE\n") {
                                list = Blist;
                            }
                            //textArea1.setText(list);
                            textArea2.setText(list);
                            list = "";
                            Alist = "AFTER\n";
                            Blist = "\n\nBEFORE\n";

                        }


                    } catch (IOException ex) {
                        // LOG or output exception
                        ex.printStackTrace();
                    }

                }else {
                    // alert to say no file was select if open file button is pressed and nothing was selected
                    JOptionPane.showMessageDialog(null, "File or Folder not Selected!\n Please try again!");
                }

            }
        });
        // action for browse for file button
        browseForFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // set up JFrame and JFileChooser to be able to browse files
                JFrame window = new JFrame("Browse for Folder");
                final JButton openFileChooser = new JButton("Open JFileChooser");
                window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                final JFileChooser fc = new JFileChooser();

                // set current directory and open file chooser
                fc.setCurrentDirectory(new File("/Users/jerrod/Desktop/college/Junior/Spring Semester/SCS 400 01 Computer Systems Research: Semina"));
                fc.setDialogTitle("Browse for Folder");
                fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                //if option is approved then save path in source path and set label
                if (fc.showOpenDialog(openFileChooser) == JFileChooser.APPROVE_OPTION) {
                     FolderPath = fc.getSelectedFile().getAbsolutePath().toString();
                     noFolderSelectedLabel.setText(FolderPath);
                    //textField1.setText(SourcePath);
                    //show message of overall path
                    //JOptionPane.showMessageDialog(null, fc.getSelectedFile().getAbsolutePath());
                }
            }
        });
        browseForComareFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // set up JFrame and JFileChooser to be able to browse files
                JFrame window = new JFrame("Browse for File");
                final JButton openFileChooser = new JButton("Open JFileChooser");
                window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                final JFileChooser fc = new JFileChooser();

                // set current directory and open file chooser
                fc.setCurrentDirectory(new File("/Users/jerrod/Desktop/college/Junior/Spring Semester/SCS 400 01 Computer Systems Research: Semina"));
                fc.setDialogTitle("Browse for File");
                fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                //if option is approved then save path in source path and set label
                if (fc.showOpenDialog(openFileChooser) == JFileChooser.APPROVE_OPTION) {
                    FilePath = fc.getSelectedFile().getAbsolutePath().toString();
                    noFileSelectedLbl.setText(FilePath);
                    //textField1.setText(SourcePath);
                    //show message of overall path
                    //JOptionPane.showMessageDialog(null, fc.getSelectedFile().getAbsolutePath());
                }
            }
        });


    }

    public static void main(String[] args) {

        //set up main JFrame and panel and set as visible
        JFrame frame = new JFrame("App");
        frame.setPreferredSize(new Dimension(1000,400));
        frame.setContentPane(new App().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
    static void getAttributes(String pathStr, String name) throws IOException {
        Path p = Paths.get(pathStr);
        BasicFileAttributes view
                = Files.getFileAttributeView(p, BasicFileAttributeView.class)
                .readAttributes();
        System.out.println("Creation Time: "+view.creationTime()+", Last Modified Time: "+view.lastModifiedTime()+", Last Access Time: "+view.lastAccessTime() + " - " + name);
    }
}
